import { TribeClient } from "@tribeplatform/gql-client";
import { MemberStatusInput } from "@tribeplatform/gql-client/types";

const accessToken =
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IkFQUDo6SjkzU0pVMlBPdUlZIiwiZXh0ZXJuYWxBY3RvcklkIjoiQVBQOjpKOTNTSlUyUE91SVkiLCJuZXR3b3JrSWQiOiIzdkNKdkZucDNWIiwidG9rZW5UeXBlIjoiTElNSVRFRCIsImVudGl0eUlkIjoiM3ZDSnZGbnAzViIsInBlcm1pc3Npb25Db250ZXh0IjoiTkVUV09SSyIsInBlcm1pc3Npb25zIjpbIioiXSwiaWF0IjoxNjc1NDM4NTg0LCJleHAiOjE2NzgwMzA1ODR9.veVPGvth5AwSCLuYEaqobrorkKpk2dRaD55L7DFRK9c";

const client = new TribeClient({
  graphqlUrl: "https://app.tribe.so/graphql",
  accessToken: accessToken,
});

exports.handler = async (event) => {
  await client.members
    .list({
      limit: 10,
      status: MemberStatusInput.VERIFIED,
    })
    .then((items) => {
      items.edges.map((node) => console.log("Members:", node.node.name));
    });
};

// client.members
//   .list({
//     limit: 10,
//     status: MemberStatusInput.VERIFIED,
//   })
//   .then((items) => {
//     items.edges.map((node) => console.log("Members:", node.node.name));
//   });

// async function generateAccessToken() {
//   const client = new TribeClient({
//     graphqlUrl: "https://app.tribe.so/graphql",
//     clientId: "e4d71012-479d64ba0465",
//     clientSecret: "8cfb50bca66e4764a725db297820af4a",
//   });

//   client
//     .generateToken({
//       networkId: "3vCJvFnp3V",
//     })
//     .then(async (accessToken) => {
//       return accessToken;
//     });
// }
