import { TribeClient } from "@tribeplatform/gql-client";
// mention id TbK5Ssjosl
const accessToken =
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IkFQUDo6SjkzU0pVMlBPdUlZIiwiZXh0ZXJuYWxBY3RvcklkIjoiQVBQOjpKOTNTSlUyUE91SVkiLCJuZXR3b3JrSWQiOiIzdkNKdkZucDNWIiwidG9rZW5UeXBlIjoiTElNSVRFRCIsImVudGl0eUlkIjoiM3ZDSnZGbnAzViIsInBlcm1pc3Npb25Db250ZXh0IjoiTkVUV09SSyIsInBlcm1pc3Npb25zIjpbIioiXSwiaWF0IjoxNjc1NzczNjA1LCJleHAiOjE2NzgzNjU2MDV9.hsdVmp6MAJU2-jfpD9y_ZM3UKOgn1BeUCAV-lJMx3xA";
const client = new TribeClient({
  graphqlUrl: "https://app.tribe.so/graphql",
  accessToken: accessToken,
});
const members = await client.members
  .list({
    limit: 100,
    flagged: false,
  })
  .then((res) => {
    return res.edges.map((node) => node.node);
  });

console.log(members);

// client.posts
//   .list({
//     limit: 10,
//     query: "Match match",
//   })
//   .then((items) => console.log(items));
// client.posts.listPostTypes({ limit: 10 }).then((items) => console.log(items));

// client.spaces
//   .list(
//     {
//       limit: 10,
//       query: "Random",
//     },
//     "basic"
//   )
//   .then((items) => console.log(items));

// client.posts.listPostTypes({ limit: 10 }).then((items) => console.log(items));
// client.postType
//   .list({ limit: 10, query: "Discussion" })
//   .then((items) => console.log(items)); // .nodes[0].mappings

// feed id 152m3aprHrR7; Random COffee 9oizLsjloepB

// article id 22Bh1XMpfZZBoFN; discussion R78fANh7O7d1H2v

// client.posts.feed({ limit: 10 }).then((items) => console.log(items));

// client.members
//   .list({
//     limit: 10,
//     status: MemberStatusInput.VERIFIED,
//   })
//   .then((items) => {
//     items.edges.map((node) => console.log("Members:", node.node));
//   });

// async function generateAccessToken() {
//   const client = new TribeClient({
//     graphqlUrl: "https://app.tribe.so/graphql",
//     clientId: "e4d71012-479d64ba0465",
//     clientSecret: "8cfb50bca66e4764a725db297820af4a",
//   });

//   client
//     .generateToken({
//       networkId: "3vCJvFnp3V",
//     })
//     .then(async (accessToken) => {
//       //   return accessToken;
//       console.log(accessToken);
//     });
// }

// generateAccessToken();
